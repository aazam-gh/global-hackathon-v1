#---------------------------------------------------------
# File:   mit18_05_s22_RQuizPractice.r 
# Authors: Jeremy Orloff and Jennifer French
#
# MIT OpenCourseWare: https://ocw.mit.edu
# 18.05 Introduction to Probability and Statistics
# Spring 2022
# For information about citing these materials or our Terms of Use, visit:
# https://ocw.mit.edu/terms.
#
#---------------------------------------------------------
# R Practice Quiz

# This is much much longer than the actual quiz.

#---------------------------------
# 0.a. Clean your space.

# The following will clean the environment
rm(list=ls())  #clear environment
cat("\014")    #clear RStudio console 


#--------------------------------------
# Problem 1:  Basics
# See instructions.

rquiz_practice_problem_1a = function(n_samples, mu, sigma) {
  cat("----------------------------------\n")
  cat("Problem 1a: sampling from a normal distribution\n")

  # Arguments:
  # n_samples = size of the sample to generate
  # mu = mean of the underlying normal distribution
  # sigma = standard deviation of the underlying normal distribution

  # Do not change the above code.
  # ********* YOUR CODE HERE ***********

}

rquiz_practice_problem_1b = function(n_samples, size, theta) {
  cat("-----\n")
  cat("1b: sampling from a binomial distribution\n")

  # Arguments:
  # n_samples = size of the sample to generate
  # size =  number of Bernoulli trials
  # theta = probability of success in each Bernoulli trial

  # Do not change the above code.
  # ********* YOUR CODE HERE ***********

}

rquiz_practice_problem_1c = function(sample_space, n_samples) {
  cat("-----\n")
  cat("1c: sampling from a list with replacement\n")

  # Arguments:
  # sample_space = the list of outcomes to sample from
  # n_samples = number of the sample to generate

  # Do not change the above code.
  # ********* YOUR CODE HERE ***********

}

rquiz_practice_problem_1d = function(n) {
  cat("-----\n")
  cat("1d: Permutations\n")

  # Arguments:
  # n = the problem asks you to generate a permutation of the numbers 1:n

  # Do not change the above code.
  # ********* YOUR CODE HERE ***********

}

rquiz_practice_problem_1e = function(w, x_1) {
  cat("-----\n")
  cat("1e: Plotting\n")

  # Arguments:
  # w = angular frequency (for sin(w*x) and cos(w*x))
  # x_1: plot from 0 to x_1
  
  # Do not change the above code.
  # ********* YOUR CODE HERE ***********


  
  cat('See plot: Plot for problem 1e','\n')
}

rquiz_practice_problem_1f = function(n_samples, a, b) {
  cat("-----\n")
  cat("1f: Sampling and basic statistics\n")

  # Arguments:
  # n_samples = number of samples to generate from a Uniform(a,b) distribution.
  # a = left endpoint for the Uniform(a,b) distribution.
  # b = right endpoint for the Uniform(a,b) distribution.

  
  # Do not change the above code.
  # ********* YOUR CODE HERE ***********

}

rquiz_practice_problem_1g = function(n_samples, a, b) {
  cat("-----\n")
  cat("1g: Sampling and basic statistics\n")

  # Arguments:
  # n_samples = number of samples to generate from a Uniform(a,b) distribution.
  # a = left endpoint for the Uniform(a,b) distribution.
  # b = right endpoint for the Uniform(a,b) distribution.
  
  # Do not change the above code.
  # ********* YOUR CODE HERE ***********

}

rquiz_practice_problem_1h = function(n_samples, mu1, sigma1, mu2, sigma2, alpha, mu0, sigma0) {
  cat("-----\n")
  cat("1h: Sampling and basic statistics\n")

  # Arguments:
  # n_samples = number of samples to generate from each normal distribution.
  # mu1 = mean for the first normal distribution
  # sigm1 = standard deviation for the first normal distribution.
  # mu2 = mean for the second normal distribution
  # sigm2 = standard deviation for the second normal distribution.
  # alpha = significance level for tests
  # mu0, sigma0 are the mean and standard deviation for H0. (sigma0 is not used in the t-test comparing means)

  
  # Do not change the above code.
  # ********* YOUR CODE HERE ***********

}

#--------------------------------------
# Problem 2: Bayesian update simulation.
# See instructions for this studio

rquiz_practice_problem_2 = function(prior, next_roll) {
  cat("----------------------------------\n")
  cat("Problem 2: Simulation with a mixture of coins\n")

  # Arguments:
  #   prior = prior probability for the dice choice (5 numbers, usual order)
  #   next_roll = the problem asks for the predictive probability of next_roll on the next roll.

  # Here's the code to load the likelihood table.
  rownames = c('sides = 4', 'sides = 6', 'sides = 8', 'sides = 12', 'sides = 20')
  colnames = c('x=1','x=2','x=3','x=4','x=5','x=6','x=7','x=8','x=9','x=10', 'x=11','x=12','x=13','x=14','x=15','x=16','x=17','x=18','x=19','x=20')
  standard_likelihood_table = matrix(0,nrow=5, ncol=20, dimnames=list(rownames,colnames))
  standard_likelihood_table[1,1:4] = 1/4    #4 sided die
  standard_likelihood_table[2,1:6] = 1/6    #6 sided die
  standard_likelihood_table[3,1:8] = 1/8    #8 sided die
  standard_likelihood_table[4,1:12] = 1/12  #12 sided die
  standard_likelihood_table[5,1:20] = 1/20  #20 sided die
  # print(standardLikelihoodTable)


  # Do not change the above code.
  # ********* YOUR CODE HERE ***********


}


#--------------------------------------
# Problem 3:  Counting
# See instructions.

rquiz_practice_problem_3a = function(n_rats) {
  cat("----------------------------------\n")
  cat("Problem 3a: counting Brass rats\n")

  # Arguments:
  # n_rats = number of Brass Rats Tim has
  
  # Do not change the above code.
  # ********* YOUR CODE HERE ***********


}

rquiz_practice_problem_3b = function(n_ways) {
  cat("----------------------------------\n")
  cat("Problem 3b: more counting Brass Rats\n")

  # Arguments:
  # n_ways = minimum number of ways Tim wants to be able to wear their Brass Rats.

  # Do not change the above code.
  # ********* YOUR CODE HERE ***********
  

}

#--------------------------------------
# Problem 4: Polling
# See instructions.

rquiz_practice_problem_4a = function(n_students, theta_tim) {
  cat("----------------------------------\n")
  cat("Problem 4a: Plot binomial\n")

  # Arguments:
  # n_students = the number of students polled
  # theta_tim = true fraction of the student population that supports Tim

  # Do not change the above code.
  # ********* YOUR CODE HERE ***********


}

rquiz_practice_problem_4b = function(n_students, n_support_tim, theta_H0, alpha) {
  cat("-----\n")
  cat("Problem 4b: NHST\n")

  # Arguments:
  # n_students = the number of students polled
  # n_support_tim = the number of who support Tim in the poll
  # theta_HO = For H0, the fraction of the student population that supports Tim
  # alpha = significance level for NHST

  # Do not change the above code.
  # ********* YOUR CODE HERE ***********

}


#--------------------------------------
# Problem 5: Simulation of exponential data
# See instructions.

rquiz_practice_problem_5a = function(lambda) {
  cat("----------------------------------\n")
  cat("Problem 5a: Plot exponential\n")

  # Arguments:
  # lambda = rate parameter for the exponential distribution

  
  # Do not change the above code.
  # ********* YOUR CODE HERE ***********

}

rquiz_practice_problem_5b = function(lambda, n_bus_trips) {
  cat("-----\n")
  cat("Problem 5b: Simulation\n")

  # Arguments:
  # lambda = rate parameter for exponential distribution
  # n_bus_trips = the number of Hack's bus trips to simulate

  # Do not change the above code.
  # ********* YOUR CODE HERE ***********

}


#--------------------------------------
# Problem 6: Gambling: theory and simulation
# See instructions.

rquiz_practice_problem_6a = function(n_bets_per_day, n_days) {
  cat("----------------------------------\n")
  cat("Problem 6a: Theoretical mean and variance\n")

  # Arguments:
  # n_bets_per_day = number of bets Punt makes each day
  # n_days = number of days Punt plays
  
  # Do not change the above code.
  # ********* YOUR CODE HERE ***********

}

rquiz_practice_problem_6b = function(n_bets_per_day, n_days, n_trials) {
  cat("-----\n")
  cat("Problem 6b: Simulation\n")

  # Arguments:
  # n_bets_per_day = number of bets Punt makes each day
  # n_days = number of days Punt plays
  # n_trials = number of simulations of n_days of betting to run
  
  # Do not change the above code.
  # ********* YOUR CODE HERE ***********

}

#--------------------------------------
# Problem 7: Using Google
# See instructions.

rquiz_practice_problem_7 = function(mit_times, harvard_times, alpha) {
  cat("----------------------------------\n")
  cat("Problem 7: Using google\n")

  # Arguments:
  # mit_times = list of times for the MIT students
  # harvard_times = list of times for the Harvard students
  # alpha = significance level for test
  
  # Do not change the above code.
  # ********* YOUR CODE HERE ***********

}
