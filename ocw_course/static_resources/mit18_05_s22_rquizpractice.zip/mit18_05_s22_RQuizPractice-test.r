#---------------------------------------------------------
# File:   mit18_05_s22_RQuizPractice-test.r 
# Authors: Jeremy Orloff and Jennifer French
#
# MIT OpenCourseWare: https://ocw.mit.edu
# 18.05 Introduction to Probability and Statistics
# Spring 2022
# For information about citing these materials or our Terms of Use, visit:
# https://ocw.mit.edu/terms.
#
#---------------------------------------------------------
# Practice R Quiz test script

# Before running: clean your environment and source('mit18_05_s22_RQuizPractice.r')

#-----------------------
# Problem 1
rquiz_practice_problem_1a(8, 0, 1)
rquiz_practice_problem_1b(10, 10, 0.3)

sample_space = c('Yes', 'No', 'Maybe')
rquiz_practice_problem_1c(sample_space, 7)

rquiz_practice_problem_1d(6)
rquiz_practice_problem_1e(2, 2*pi)
rquiz_practice_problem_1f(5000, 1, 5)
rquiz_practice_problem_1g(50, 1,3)

rquiz_practice_problem_1h(50, 0, 2, 1.5, 2, 0.05, 0, 2)
rquiz_practice_problem_1h(50, 0, 2, 0, 2, 0.05, 0, 2)
rquiz_practice_problem_1h(50, 1, 5, 1.5, 2, 0.05, 0, 2)

#------------------------------
# Problem 2
rquiz_practice_problem_2(c(0.4, 0.2, 0.2, 0.1, 0.1), 4)
rquiz_practice_problem_2(c(0.4, 0.2, 0.2, 0.1, 0.1), 12)

#------------------------------
# Problem 3
rquiz_practice_problem_3a(3)
rquiz_practice_problem_3a(4)

rquiz_practice_problem_3b(30000)

#------------------------------
# Problem 4
rquiz_practice_problem_4a(200, 0.7)
rquiz_practice_problem_4b(200, 129, 0.7, 0.05)
rquiz_practice_problem_4b(200, 128, 0.7, 0.05)

#------------------------------
# Problem 5
rquiz_practice_problem_5a(0.2)
rquiz_practice_problem_5b(0.2, 1000)

#------------------------------
# Problem 6
rquiz_practice_problem_6a(40, 7)
rquiz_practice_problem_6b(40, 8, 10000)

#------------------------------
# Problem 7
set.seed(1)
mit_times = rnorm(25, 15, 4)
harvard_times = rnorm(25, 18, 5)
rquiz_practice_problem_7(mit_times, harvard_times, 0.05)

    
