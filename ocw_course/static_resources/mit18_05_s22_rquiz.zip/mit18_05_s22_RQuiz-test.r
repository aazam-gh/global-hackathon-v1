#---------------------------------------------------------
# File:   mit18_05_s22_RQuiz-test.r 
# Authors: Jeremy Orloff and Jennifer French
#
# MIT OpenCourseWare: https://ocw.mit.edu
# 18.05 Introduction to Probability and Statistics
# Spring 2022
# For information about citing these materials or our Terms of Use, visit:
# https://ocw.mit.edu/terms.
#
#---------------------------------------------------------
# R Quiz test script

# Before running: clean your environment and source('mit18_05_s22_RQuiz.r')

#-----------------------
# Problem 1
rquiz_problem_1a(3, 2, 2, 3, -3, 11)
rquiz_problem_1b(18, 6, 14)
rquiz_problem_1b(10000, 1201, 55)

theta_values = c(0.1, 0.4, 0.5, 0.7, 0.9)
rquiz_problem_1c(theta_values, 200, 78)

theta_values = c(0.4, 0.6, 0.8, 1.0)
rquiz_problem_1c(theta_values, 50, 38)

#------------------------------
# Problem 2
rquiz_problem_2a(1000, 10, 0.5)
rquiz_problem_2a(1000, 30, 0.5)
rquiz_problem_2b(10000, 100, 2, 0.2)

#------------------------------
# Problem 3
set.seed(42)
rquiz_problem_3(rnorm(200, 3, 4), 0.05)
rquiz_problem_3(rt(200, 1), 0.05)
rquiz_problem_3(rt(30, 4), 0.1)

#------------------------------
# Problem 4 (Extra credit)
# Make sure the WORKING DIRECTORY is set to the source file
rquiz_problem_4('mit18_05_s22_RQuiz_data_prob4_test.txt', 0.05)
