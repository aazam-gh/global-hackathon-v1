#---------------------------------------------------------
# File:   mit18_05_s22_RQUIZ-samplecode.r 
# Authors: Jeremy Orloff and Jennifer French
#
# MIT OpenCourseWare: https://ocw.mit.edu
# 18.05 Introduction to Probability and Statistics
# Spring 2022
# For information about citing these materials or our Terms of Use, visit:
# https://ocw.mit.edu/terms.
#
#---------------------------------------------------------
# R Quiz samplecode

# Here's a tiny bit of code that may help

# Most tests in R return a data structure that includes the p-value of the test and the test statistic.

#To get the p-values you  use result$p.value. Likewise for result$statistic.

#Here is an example
x = rnorm(30, 0.6, 1)
result = t.test(x, mu=0)
p.value = result$p.value
test_stat = result$statistic

cat(p.value, test_stat, '\n')

# In general, in RStudio if you type 'result$' then R will give you all the ways to complete this, i.e. the names of all the values stored in the data structure 
