#---------------------------------------------------------
# File:   mit18_05_s22_RQuiz.r 
# Authors: Jeremy Orloff and Jennifer French
#
# MIT OpenCourseWare: https://ocw.mit.edu
# 18.05 Introduction to Probability and Statistics
# Spring 2022
# For information about citing these materials or our Terms of Use, visit:
# https://ocw.mit.edu/terms.
#
#---------------------------------------------------------
# R Quiz 

# READ THE INSTRUCTIONS PDF!
# * Read the problems carefully
# * Save your work frequently
# * You may use any resources except another person
#    (This includes, paper, books, code on your computer,
#    code on the internet ...)
# * If code is given with a question it is meant to be used. Don't just ignore it.
# * Remember to use print or cat statements to print the values asked for
# * Before uploading the code: clear your environment and source the entire file (choose source from the code menu)
#   -- Make sure that it runs without error and outputs just the answers asked for in the questions.

#-------------------------------
# 0. Run this to clean the environment

rm(list=ls())  #clear environment
cat('\014') #clear RStudio console

#--------------------------------
# Problem 1 (20: 5, 5, 10 points)
# See the instructions pdf

rquiz_problem_1a = function(mu, sigma, w_shape, w_scale, a, b) {
  cat("----------------------------------\n")
  cat("Problem 1a (5 points): Graphs\n")

  # Arguments:
  # mu = mean of the normal pdf to plot
  # sigma = standard deviation of the normal pdf to plot
  # w_shape = shape parameter for Weibull pdf
  # w_scale = scale parameter for Weibull pdf
  # a, b = endpoints of the range of x for the plot


  # Do not change the above code.
  # ********* YOUR CODE HERE ***********


  cat('See plots\n')
}

rquiz_problem_1b = function(n, k, m) {
  cat("-----\n")
  cat("Problem 1b (5 points): Combinations and factorials\n")

  # Arguments:
  # n = see instructions below
  # k = see instructions below
  # m = see instructions below
  
  # The problem asks you to print out n choose k, m factorial, log of n choose k.

  # Do not change the above code.
  # ********* YOUR CODE HERE ***********

}

rquiz_problem_1c = function(theta_values, num_patients, num_cured) {
  cat("-----\n")
  cat("Problem 1c (10 points): Bayesian coins \n")

  # Arguments:
  # theta_values = List of possible values of theta.
  # num_patients = The number of patients in the trial.
  # num_cured = The number of successes in the trial.
  

  # Do not change the above code.
  # ********* YOUR CODE HERE ***********

}

#--------------------------------
# Problem 2 (20 10:10 points) Histograms
# See the instructions pdf

rquiz_problem_2a = function(n_draws, k, bin_width) {
  cat("----------------------------------\n")
  cat("Problem 2a (10 points): Density histograms\n")

  # Arguments:
  # n_draws = Number of sample points in the histogram
  # k = Number of degrees of freedom for the chi-square distribution
  # bin_width = Bin width for histogram
  

  # Do not change the above code.
  # ********* YOUR CODE HERE ***********


  cat('See plots\n')
}

rquiz_problem_2b = function(n_trials, n_draws, k, bin_width) {
  cat("-----\n")
  cat("Problem 2b (10 points): Density histograms\n")

  # Arguments:
  # n_trials = Number of trials
  # n_draws = Number of sample points in each trial
  # k = Number of degrees of freedom for the chi-square distribution
  # bin_width = Bin width for histogram
  

  # Do not change the above code.
  # ********* YOUR CODE HERE ***********


  cat('See plots\n')
}

#--------------------------------
# Problem 3 (10  points)
# See the instructions pdf

rquiz_problem_3 = function(our_data, alpha) {
  cat("----------------------------------\n")
  cat("Problem 3 (10 points): \n")

  # Arguments:
  # our_data = data from some experiment
  # alpha = significance level for the Shapiro-Wilk test

  # Do not change the above code.
  # ********* YOUR CODE HERE ***********

}

#--------------------------------
# Problem 4 (Extra credit 5 points)
# See the instructions pdf

rquiz_problem_4 = function(data_file_name, alpha) {
  cat("----------------------------------\n")
  cat("Problem 4 (Extra credit: 5 points): \n")


  # Arguments:
  # data_file_name = data file
  # alpha = Significance level for t-test

  # Read the data from the file
  data = read.table(data_file_name)
  x = data$x
  y = data$y

  # Do not change the above code.
  # ********* YOUR CODE HERE ***********

}
