#---------------------------------------------------------
# File:   mit18_05_s22_studio1-grader 
# Authors: Jeremy Orloff and Jennifer French
#
# MIT OpenCourseWare: https://ocw.mit.edu
# 18.05 Introduction to Probability and Statistics
# Spring 2022
# For information about citing these materials or our Terms of Use, visit:
# https://ocw.mit.edu/terms.
#
#---------------------------------------------------------
# Grade studio 1
#-----------
# Expected output in studio1-grader.html
# If this file changes --need to rebuild studio*-grader.html

# Use 'File > Compile report...' to create an R Markdown report from this.
# Because this opens a new session, it doesn't see the environment.
# So we need the following line, which should be commented out when using the grading script for grading.

# source('mit18_05_s22_studio1-solutions.r')  ### COMMENT OUT FOR GRADING
# cat("WARNING: make sure source('mit18_05_s22_studio1-solutions.r') is commented out before grading\n")

#--------------
# For grading, open this file and set working directory to source file location

#--------------
studio1_problem_2a(200, 20, 8000)
studio1_problem_2b()
studio1_problem_3(200, 2000)
