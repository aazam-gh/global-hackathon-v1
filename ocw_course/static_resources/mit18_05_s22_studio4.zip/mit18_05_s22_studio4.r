#---------------------------------------------------------
# File:   mit18_05_s22_studio4.r 
# Authors: Jeremy Orloff and Jennifer French
#
# MIT OpenCourseWare: https://ocw.mit.edu
# 18.05 Introduction to Probability and Statistics
# Spring 2022
# For information about citing these materials or our Terms of Use, visit:
# https://ocw.mit.edu/terms.
#
#---------------------------------------------------------
# Studio 4 ----

# 1. Be sure to read the instructions file!

# 2. The instruction file gives instructions for testing your code. You can see the output of the tests in studio4-test-answers.html. You should use this to verify your code is giving correct output in the format asked for.

# 3. The handouts section (right side) of our MITx course page has a link for uploading you work.

#---------------------------------
# Problem 1: Barto and Axel simulated covariance and correlation. ----
# See the instructions for this studio.

# 1a: Simulated covariance and correlation.
studio4_problem_1a = function(n_together, n_Barto_alone, ntrials) {
  cat("\n----------------------------------\n")
  cat("Problem 1a. Barto and Axel simulated covariance and correlation.\n")

  # Arguments:
  #   n_together = number of games Axel and Barto play together
  #   n_Barto_alone = number of games Barto plays after playing with Axel
  #   ntrials = number of trials to run in one simulation.

  # Do not change the above code.
  # ********* YOUR CODE BELOW HERE ***********

  
  #------
  # Use the cat statements below to print your results. You will need to insert your variables names where indicated.
  cat("For n_together =", n_together, " and n_Barto_alone =", n_Barto_alone, "we have\n")
  cat("Axel's sample mean is", 'YOUR_VARIABLE_HERE', '\n')
  cat("Barto's sample mean is", 'YOUR_VARIABLE_HERE', '\n')
  cat("Axel's sample variance is", 'YOUR_VARIABLE_HERE', '\n')
  cat("Barto's sample variance is", 'YOUR_VARIABLE_HERE', '\n')
  cat("Their sample covariance is", 'YOUR_VARIABLE_HERE', '\n')
  cat("Their sample correlation is", 'YOUR_VARIABLE_HERE', '\n')
}


# 1b. Print your description of what happens as n_Barto_alone increases
studio4_problem_1b = function() {
  cat("-----\n")
  cat("1b. Describe behavior as n_Barto_alone increases\n")

  # Do not change the above code.
  # ********* YOUR CODE BELOW HERE ***********

  cat('As n_Barto_alone increases, the covariance, YOUR_DESCRIPTION_HERE. \n')
  cat('As n_Barto_alone increases, the correlation, YOUR_DESCRIPTION_HERE. \n')
}

#-------------------------------------
# Problem 2: Simulated central limit theorem. ----
# This is cool and shouldn't take a lot of code.
studio4_problem_2 = function(n_bets_per_trial, ntrials) {
  cat("\n----------------------------------\n")
  cat("Problem 2. Simulated central limit theorem.\n")

  # Arguments:
  #   n_bets_per_trial = the number of bets in each trial
  #   n_trials = number of trials

  # Do not change the above code.
  # ********* YOUR CODE HERE ***********


  #------
  cat('See plot\n')
}
