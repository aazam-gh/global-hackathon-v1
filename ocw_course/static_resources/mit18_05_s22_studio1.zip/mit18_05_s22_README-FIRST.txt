Start by reading the instructions in mit18_05_s22_studio1-instructions.
