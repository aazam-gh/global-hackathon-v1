#---------------------------------------------------------
# File:   mit18_05_s22_studio7-solutions-no-explain.r 
# Authors: Jeremy Orloff and Jennifer French
#
# MIT OpenCourseWare: https://ocw.mit.edu
# 18.05 Introduction to Probability and Statistics
# Spring 2022
# For information about citing these materials or our Terms of Use, visit:
# https://ocw.mit.edu/terms}.
#
#---------------------------------------------------------
# studio7-solutions-no-explain.r
#
# For use in studio7-test-answers.Rmd to override certain print statements


#--------------------------------------
# Problem 1: Use studio7-solutions

#--------------------
# Problem 2: Use studio7-solutions

#--------------------
# Problem 3: Simulation with only fair coins

# We fake problem_2 for use in problem_3, to get 'non-give-away' output
fake_studio7_problem_2 = function(theta_HA, alpha, n_tosses, n_trials, secret_prior) {
  cat("----------------------------------\n")
  cat("Problem 2: Simulation with a mixture of coins\n")

  FAKE_VALUE = "???"
  
  cat("  theta_HA=", theta_HA, ", alpha=", alpha, '\n', sep='')
  cat("  n_tosses=", n_tosses, ", n_trials=", n_trials, '\n', sep='')
  cat("  secret_prior=", secret_prior, '\n')

  cat("\n Giving the actual output from this function will give too much away. So we blank out the answers with ???\n")
  cat("  Number of rejections: ", FAKE_VALUE, '\n')
  cat("  Number of type 1: ", FAKE_VALUE, '\n')
  cat("  Number of type 2: ", FAKE_VALUE, '\n')
  cat("  P(rejection | H0): ", FAKE_VALUE, '\n')
  cat("  P(H0 | rejection): ", FAKE_VALUE, '\n')
  cat("  P(rejection | HA): ", FAKE_VALUE, '\n')
  cat("  P(HA | rejection): ", FAKE_VALUE, '\n')
}

studio7_problem_3a = function(theta_HA, alpha, n_tosses, n_trials) { 
  cat("-----\n")
  cat("3a: Simulation with all fair coins: explain results\n")

  secret_prior = c(1.0, 0) # Prob of H0, prob of HA
  cat("----\n")
  fake_studio7_problem_2(theta_HA, alpha, n_tosses, n_trials, secret_prior)
  cat("# Problem 2 called from problem 3a")
  # This is faked
  
  cat("----\n")
  
  cat("  You need to edit the cat statements at the end of studio7_problem_3a() to give a short explanation of the estimated probabilities that go with the given prior.\n")
}

studio7_problem_3b = function(theta_HA, alpha, n_tosses, n_trials) { 
  cat("-----\n")
  cat("3b: Simulation with all ubfair coins: explain results\n")

  secret_prior = c(0, 1.0) # Prob of H0, prob of HA
  cat("----\n")
  fake_studio7_problem_2(theta_HA, alpha, n_tosses, n_trials, secret_prior)
  cat("# Problem 2 called from problem 3b")
  # This is faked
  
  cat("----\n")
  
  cat("  You need to edit the cat statements at the end of studio7_problem_3b() to give a short explanation of the estimated probabilities that go with the given prior.\n")
}

studio7_problem_3c = function() { 
  cat("-----\n")
  cat("3c: Explain difference between P(H0 | rejection) and significance\n")

  cat("  You need to edit the cat statements at the end of studio7_problem_3c() to explain the difference asked about.\n")
}

studio7_problem_3d = function() { 
  cat("-----\n")
  cat("3d: Shout it out!\n")

  cat("  You need to edit the cat statements at the end of studio7_problem_3d() to shout and say what is asked.\n")
}


#--------------------
# OPTIONAL Problem 4: Use studio7-solutions.r

#-----------------------------
