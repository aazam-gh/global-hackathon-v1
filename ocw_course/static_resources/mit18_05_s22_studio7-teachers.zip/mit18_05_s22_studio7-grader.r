#---------------------------------------------------------
# File:   mit18_05_s22_studio7-grader.r 
# Authors: Jeremy Orloff and Jennifer French
#
# MIT OpenCourseWare: https://ocw.mit.edu
# 18.05 Introduction to Probability and Statistics
# Spring 2022
# For information about citing these materials or our Terms of Use, visit:
# https://ocw.mit.edu/terms}.
#
#---------------------------------------------------------
# Studio 7 grading script

#-----------
# Expected output in studio7-grader.html
# If this file changes --need to rebuild studio*-grader.html

# Use 'File > Compile report...' to create an R Markdown report from this.
# Because this opens a new session, it doesn't see the environment.
# So we need the following line, which should be commented out when using the grading script for grading.

# source('mit18_05_s22_studio7-solutions.r')  ### COMMENT OUT FOR GRADING
# cat("WARNING: make sure source('mit18_05_s22_studio*-solutions.r') is commented out before grading\n")

#-----------------------
# For grading, open this file and set working directory to source file location

#-----------------------
studio7_problem_1(0.65, 0.06, 25)

#-----------------------
studio7_problem_2(0.65, 0.06, 25, 2000, c(0.2, 0.8))

#-----------------------
studio7_problem_3a(0.65, 0.06, 25, 2000)
studio7_problem_3b(0.65, 0.06, 25, 2000)
studio7_problem_3c()
studio7_problem_3d()

#-----------------------
# OPTIONAL 
studio7_problem_4(0.65, 0.06, 25, c(0.2, 0.8))
# Compare the problem 4 results with the simulated results in problem 2.
studio7_problem_2(0.65, 0.06, 25, 10000, c(0.2, 0.8))
