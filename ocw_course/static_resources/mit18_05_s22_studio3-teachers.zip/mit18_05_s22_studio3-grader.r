#---------------------------------------------------------
# File:   mit18_05_s22_studio3-grader.r 
# Authors: Jeremy Orloff and Jennifer French
#
# MIT OpenCourseWare: https://ocw.mit.edu
# 18.05 Introduction to Probability and Statistics
# Spring 2022
# For information about citing these materials or our Terms of Use, visit:
# https://ocw.mit.edu/terms.
#
#---------------------------------------------------------
# Studio 3 grader

#-----------
# Expected output in studio3-grader.html
# If this file changes --need to rebuild studio*-grader.html

# Use 'File > Compile report...' to create an R Markdown report from this.
# Because this opens a new session, it doesn't see the environment.
# So we need the following line, which should be commented out when using the grading script for grading.

# source('mit18_05_s22_studio3-solutions.r')  ### COMMENT OUT FOR GRADING
# cat("WARNING: make sure source('mit18_05_s22_studio3-solutions.r') is commented out before grading\n")

#--------------
# For grading, open this file and set working directory to source file location

#--------------
studio3_problem_1a(2, 1000)
studio3_problem_1b(2, 1000)
studio3_problem_2a(2, 1000)
studio3_problem_2b(2, 4000, 4, 0.05)
studio3_problem_2b(2, 4000, 8, 0.05)
studio3_problem_2b(2, 4000, 16, 0.05)
studio3_problem_2b(2, 4000, 64, 0.05)

