#---------------------------------------------------------
# File:   mit18_05_s22_studio8-grader.r 
# Authors: Jeremy Orloff and Jennifer French
#
# MIT OpenCourseWare: https://ocw.mit.edu
# 18.05 Introduction to Probability and Statistics
# Spring 2022
# For information about citing these materials or our Terms of Use, visit:
# https://ocw.mit.edu/terms.
#
#---------------------------------------------------------
# Studio 8 grading script

#-----------
# Expected output in studio8-grader.html
# If this file changes --need to rebuild studio*-grader.html

# Use 'File > Compile report...' to create an R Markdown report from this.
# Because this opens a new session, it doesn't see the environment.
# So we need the following line, which should be commented out when using the grading script for grading.

# source('mit18_05_s22_studio8-solutions.r')  ### COMMENT OUT FOR GRADING
# cat("WARNING: make sure source('mit18_05_s22_studio*-solutions.r') is commented out before grading\n")

#-----------------------
# For grading, open this file and set working directory to source file location

#-----------------------
studio8_problem_1(7, 12, 7, 3, 10000)

#-----------------------
# Generated data with the following code
# printarray = function(x, name, rnd) {
#   if (name != '') {
#     cat(name, ' = ', sep='')
#   }
#   cat('c(', sep='')
#   cat(round(x, rnd), sep=', ')
#   cat(')\n')
# }
# n = 100
# x = rnorm(n, 5, 3)
# printarray(x, 'grade_data_problem_2', 3)
#
# n = 16
# T1 = rnorm(n, 3, 2)
# T2 = rnorm(n, 3, 2.5)
# T3 = rnorm(n, 3, 2)
# printarray(T1, 'T1', 3)
# printarray(T2, 'T2', 3)
# printarray(T3, 'T3', 3)

#--------------------------------
grade_data_problem_2 = c(12.217, 3.57,  -2.703,  0.653,  5.092,  4.35,
                         6.39,   4.872,  6.357,  0.891,  9.489, 13.523,
                         2.446,  4.848,  5.061,  3.858, 10.368,  6.457,
                         5.032,  1.283,  9.803,  4.274,  7.705,  7.908,
                         1.901,  3.546,  2.906,  6.397,  7.417,  6.675,
                         1.7,    3.424,  4.526,  0.296,  3.12,   6.113,
                         5.228,  7.037,  6.992,  1.46,   1.334,  3.812,
                         0.72,   8.16,  -0.94,   4.83,   6.861, 10.365,
                         2.485,  1.754,  7.712,  4.995,  2.061,  5.622,
                         7.864,  5.101,  8.978,  2.97,   7.046,  4.988,
                         6.619,  5.281,  2.7,   10.346,  7.425,  2.039,
                         5.084,  7.623, 10.517,  4.579, 11.71,   6.949,
                         0.627,  4.082,  5.864,  8.183,  3.89,   3.513,
                         10.302, 3.392,  6.154,  8.054,  1.368,  6.464,
                         7.77,   4.589,  5.961,  6.07,   9.4,    3.898,
                         4.242,  7.963,  4.907,  4.759,  7.903,  9.101,
                         10.617, 7.79,   6.306,  9.564)

studio8_problem_2(grade_data_problem_2, 5, 3, 0.1)
studio8_problem_2(grade_data_problem_2, 5, 3, 0.01)
studio8_problem_2(grade_data_problem_2, 0, 3, 0.1)
studio8_problem_2(grade_data_problem_2, 0, 3, 0.01)

#-----------------------
studio8_problem_3("mit18_05_s22_studio8Problem3_grade.tbl", 0.05)
studio8_problem_3("mit18_05_s22_studio8Problem3_grade.tbl", 0.01)

#-----------------------
T1 = c(1.592, -0.102, 3.924, 4.333,  4.68,  4.22,  2.749, -0.016,
       0.16,   6.067, 2.152, 2.211,  2.86,  5.831, 3.941,  3.104)
T2 = c(2.052, -0.785, 2.24,  5.096, -1.119, 4.221, 2.687, -0.134,
       8.31,   2.265, 2.169, 0.957,  3.851, 3.562, 1.218,  3.67)
T3 = c(4.812,  5.025, 3.341, 1.199,  1.588, 3.911, 5.098,  2.667,
       4.152,  0.49,  3.625, 2.848,  4.15, -0.041, 2.26,  -1.563)

studio8_problem_4(T1, T2, T3, 0.05)
studio8_problem_4(T1, T1, T1, 0.01)

