#---------------------------------------------------------
# File:   mit18_05_s22_studio5-grader.r 
# Authors: Jeremy Orloff and Jennifer French
#
# MIT OpenCourseWare: https://ocw.mit.edu
# 18.05 Introduction to Probability and Statistics
# Spring 2022
# For information about citing these materials or our Terms of Use, visit:
# https://ocw.mit.edu/terms.
#
#---------------------------------------------------------
# Studio 5 grading script

#-----------
# Expected output in studio5-grader.html
# If this file changes --need to rebuild studio*-grader.html

# Use 'File > Compile report...' to create an R Markdown report from this.
# Because this opens a new session, it doesn't see the environment.
# So we need the following line, which should be commented out when using the grading script for grading.

# source('mit18_05_s22_studio5-solutions.r')  ### COMMENT OUT FOR GRADING
# cat("WARNING: make sure source('mit18_05_s22_studio*-solutions.r') is commented out before grading\n")

#--------------
# For grading, open this file and set working directory to source file location

#-----------------------
studio5_problem_0a()
studio5_problem_0b()
studio5_problem_0c()

#-----------------------
studio5_problem_1a()

prior = c(0.2, 0.2, 0.2, 0.2, 0.2)
studio5_problem_1b(prior, 8, TRUE)

prior = c(0.4, 0.1, 0.1, 0.2, 0.1)
studio5_problem_1b(prior, 15, FALSE)
studio5_problem_1b(prior, 200, FALSE)

studio5_problem_1c()
studio5_problem_1d()

#-----------------------
studio5_problem_2a()

# 2b is OPTIONAL
prior=c(0.2, 0.2, 0.2, 0.2, 0.2)
studio5_problem_2b(prior, 30)
studio5_problem_2b(prior, 200)

