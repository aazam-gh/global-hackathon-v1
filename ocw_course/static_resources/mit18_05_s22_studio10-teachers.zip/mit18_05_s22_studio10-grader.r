#---------------------------------------------------------
# File:   mit18_05_s22_studio10-grader.r 
# Authors: Jeremy Orloff and Jennifer French
#
# MIT OpenCourseWare: https://ocw.mit.edu
# 18.05 Introduction to Probability and Statistics
# Spring 2022
# For information about citing these materials or our Terms of Use, visit:
# https://ocw.mit.edu/terms.
#
#---------------------------------------------------------
# Studio 10 grading script

#-----------
# Expected output in studio10-grader.html
# If this file changes --need to rebuild studio*-grader.html

# Use 'File > Compile report...' to create an R Markdown report from this.
# Because this opens a new session, it doesn't see the environment.
# So we need the following line, which should be commented out when using the grading script for grading.

# source('mit18_05_s22_studio10-solutions.r')  ### COMMENT OUT FOR GRADING
# cat("WARNING: make sure source('mit18_05_s22_studio*-solutions.r') is commented out before grading\n")

# Turn off progress printing
print_progress = FALSE

#-----------------------
# For grading, open this file and set working directory to source file location

#-----------------------
studio10_problem_1(0, 1, 400, 500, 500, 0.9)
studio10_problem_1(-2, 0.5, 300, 1000, 2000, 0.95)

#-----------------------
studio10_problem_2a(0, 1)
studio10_problem_2a(-4, 1.5)
studio10_problem_2a(2, 0.5)

studio10_problem_2b(0, 1, 100, 500, 1000, 0.95)
studio10_problem_2b(1, 1.5, 200, 2000, 1000, 0.9)
studio10_problem_2b(2, 0.5, 75, 600, 1000, 0.8)

#-----------------------

