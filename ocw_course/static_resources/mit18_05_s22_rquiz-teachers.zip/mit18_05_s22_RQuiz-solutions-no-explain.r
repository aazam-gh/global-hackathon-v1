#---------------------------------------------------------
# File:   mit18_05_s22_RQuiz-solutions-no-explain.r 
# Authors: Jeremy Orloff and Jennifer French
#
# MIT OpenCourseWare: https://ocw.mit.edu
# 18.05 Introduction to Probability and Statistics
# Spring 2022
# For information about citing these materials or our Terms of Use, visit:
# https://ocw.mit.edu/terms.
#
#---------------------------------------------------------
# RQuiz-solutions-no-explain.r
#
# For use in RQuiz-test-answers.Rmd to override certain print statements


#--------------------------------------
# Problem 1: Use RQuiz-solutions

#--------------------
# Problem 2: Use RQuiz-solutions

#--------------------
# Problem 3: Shapiro-Wilks test
rquiz_problem_3 = function(our_data, alpha) {
  cat("----------------------------------\n")
  cat("Problem 3 (10 points): \n")

  # Arguments:
  # our_data = data from some experiment
  # alpha = significance level for the Shapiro-Wilk test

  # Do not change the above code.
  # ********* YOUR CODE HERE ***********


  # The key is to figure out that we need shapiro.test()
  res = shapiro.test(our_data)
  p_value = res$p.value
  cat('The null hypothesis H0 is <YOU NEED TO WRITE THIS>.', '\n')
  cat('p_value =', p_value, '\n')
  if (p_value > alpha) {
    cat('Do not reject H0. ','\n')
  } else {
    cat('Reject H0 in favor of HA that <YOU NEED TO WRITE THIS>.','\n')
  }
}


#--------------------
# OPTIONAL Problem 4: Use RQuiz-solutions.r

#-----------------------------
