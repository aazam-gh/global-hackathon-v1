#---------------------------------------------------------
# File:   mit18_05_s22_RQuiz-prep.r 
# Authors: Jeremy Orloff and Jennifer French
#
# MIT OpenCourseWare: https://ocw.mit.edu
# 18.05 Introduction to Probability and Statistics
# Spring 2022
# For information about citing these materials or our Terms of Use, visit:
# https://ocw.mit.edu/terms.
#
#---------------------------------------------------------

fname = "mit18_05_s22_RQuiz_data_grader1.txt"
set.seed(4)
x = rnorm(24, 0, 1)
y = rnorm(24, 3, 1)
tbl = cbind(x, y)
print(tbl,digits=5)
# write.table(tbl, fname, append = FALSE, sep = " ", dec = ".", row.names = TRUE, col.names = TRUE)
cat('write.table commented out, so we do not keep writing the file\n')

fname = "mit18_05_s22_RQuiz_data_grader2.txt"
set.seed(8)
x = rnorm(30, 0, 1)
y = rnorm(30, 0.4, 1)
tbl = cbind(x, y)
print(tbl, digits=5)
# write.table(tbl, fname, append = FALSE, sep = " ", dec = ".", row.names = TRUE, col.names = TRUE)
cat('write.table commented out, so we do not keep writing the file\n')

