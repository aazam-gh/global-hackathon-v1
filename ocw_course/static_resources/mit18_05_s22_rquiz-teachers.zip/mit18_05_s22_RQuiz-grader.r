#---------------------------------------------------------
# File:   mit18_05_s22_RQuiz-grader.r 
# Authors: Jeremy Orloff and Jennifer French
#
# MIT OpenCourseWare: https://ocw.mit.edu
# 18.05 Introduction to Probability and Statistics
# Spring 2022
# For information about citing these materials or our Terms of Use, visit:
# https://ocw.mit.edu/terms.
#
#---------------------------------------------------------
# R Quiz grading script

#-----------
# Expected output in RQuiz-grader.html
# If this file changes --need to rebuild RQuiz-grader.html

# Use 'File > Compile report...' to create an R Markdown report from this.
# Because this opens a new session, it doesn't see the environment.
# So we need the following line, which should be commented out when using the grading script for grading.

# source('mit18_05_s22_RQuiz-solutions.r')  ### COMMENT OUT FOR GRADING
# cat("WARNING: make sure source('mit18_05_s22_RQuiz-solutions.r') is commented out before grading\n")

#-----------------------
# For grading, open this file and set working directory to source file location

#-----------------------
# Problem 1
rquiz_problem_1a(-1, 1.5, 1.5, 2, -5, 7)
rquiz_problem_1b(12, 8, 17)
rquiz_problem_1b(100000, 1001, 67)

theta_values = seq(0, 1, 0.1)
rquiz_problem_1c(theta_values, 100, 33)

theta_values = c(0.4, 0.6, 0.8, 1.0)
rquiz_problem_1c(theta_values, 10, 7)

#------------------------------
# Problem 2
rquiz_problem_2a(500, 20, 1.0)
rquiz_problem_2a(1000, 40, 1.0)
rquiz_problem_2b(10000, 500, 20, 0.2)

#------------------------------
# Problem 3
set.seed(2)
rquiz_problem_3(rnorm(300, 2, 3), 0.05)
rquiz_problem_3(runif(300, 2, 3), 0.2)
rquiz_problem_3(rt(200, 1), 0.1)
rquiz_problem_3(rt(30, 4), 0.1)

#------------------------------
# Problem 4 (Extra credit)
# Make sure the WORKING DIRECTORY is set to the source file
#------------------------------
# Problem 4 (Extra credit)
# Make sure the WORKING DIRECTORY is set to the source file
rquiz_problem_4('mit18_05_s22_RQuiz_data_prob4_test.txt', 0.05)
rquiz_problem_4('mit18_05_s22_RQuiz_data_grader1.txt', 0.05)
rquiz_problem_4('mit18_05_s22_RQuiz_data_grader2.txt', 0.05)
rquiz_problem_4('mit18_05_s22_RQuiz_data_grader2.txt', 0.01)

