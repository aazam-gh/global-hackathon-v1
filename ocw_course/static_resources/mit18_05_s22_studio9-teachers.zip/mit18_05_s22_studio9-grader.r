#---------------------------------------------------------
# File:   mit18_05_s22_studio9-grader.r 
# Authors: Jeremy Orloff and Jennifer French
#
# MIT OpenCourseWare: https://ocw.mit.edu
# 18.05 Introduction to Probability and Statistics
# Spring 2022
# For information about citing these materials or our Terms of Use, visit:
# https://ocw.mit.edu/terms.
#
#---------------------------------------------------------
# Studio 9 grading script

#-----------
# Expected output in studio9-grader.html
# If this file changes --need to rebuild studio*-grader.html

# Use 'File > Compile report...' to create an R Markdown report from this.
# Because this opens a new session, it doesn't see the environment.
# So we need the following line, which should be commented out when using the grading script for grading.

# source('mit18_05_s22_studio9-solutions.r')  ### COMMENT OUT FOR GRADING
# cat("WARNING: make sure source('mit18_05_s22_studio*-solutions.r') is commented out before grading\n")

#-----------------------
# For grading, open this file and set working directory to source file location

#-----------------------
cat("WARNING: Since confidence intervals can jump around quite a bit, a student's last confidence interval might look different from the one in the grader. By setting n_data=2048 we try to mitigate this somewhat because xbar will be more consistent")

#-----------------------
theta_vals =  seq(0, 1, 0.1)
theta_prior = c(4, 4, 4, 1, 1, 1, 1, 1, 1, 1, 1)
theta_prior = theta_prior/sum(theta_prior)
sigma = 3
n_data = 2048
confidence = 0.9
n_trials = 5000

studio9_problem_1a(theta_vals, theta_prior, sigma, n_data, confidence, n_trials) 
studio9_problem_1b(theta_vals, theta_prior, sigma, n_data, confidence, n_trials)

xbar = 0.7
studio9_problem_1c(theta_vals, theta_prior, sigma, n_data, confidence, xbar)

#-----------------------
studio9_problem_2(0.4, 900)
