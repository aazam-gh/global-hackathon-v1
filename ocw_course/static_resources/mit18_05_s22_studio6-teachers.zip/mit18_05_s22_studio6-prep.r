#---------------------------------------------------------
# File:   mit18_05_s22_studio6-prep.r 
# Authors: Jeremy Orloff and Jennifer French
#
# MIT OpenCourseWare: https://ocw.mit.edu
# 18.05 Introduction to Probability and Statistics
# Spring 2022
# For information about citing these materials or our Terms of Use, visit:
# https://ocw.mit.edu/terms.
#
#---------------------------------------------------------
# Studio 6 prep
# Generates random Cauchy data

#-----------------------------
write_test_csv_file = FALSE
write_grader_csv_file = FALSE

test_cauchy_scale = 1.0
test_cauchy_location = -0.25
test_n_samples = 15
out_test_file_name = 'mit18_05_s22_studio6_test_data_frame.csv'


grader_cauchy_scale = 1.4
grader_cauchy_location = 0.9
grader_n_samples = 35
out_grader_file_name = 'mit18_05_s22_studio6_grader_data_frame.csv'

#-----------------------------
test_cauchy_data = rcauchy(test_n_samples, location=test_cauchy_location, scale=test_cauchy_scale)
test_data_frame = data.frame(position=test_cauchy_data)
print(head(test_data_frame))

if (write_test_csv_file) {
  write.csv(test_data_frame, out_test_file_name)
}

grader_cauchy_data = rcauchy(grader_n_samples, location=grader_cauchy_location, scale=grader_cauchy_scale)
grader_data_frame = data.frame(position=grader_cauchy_data)
print(head(grader_data_frame))

if (write_grader_csv_file) {
  write.csv(grader_data_frame, out_grader_file_name)
}
