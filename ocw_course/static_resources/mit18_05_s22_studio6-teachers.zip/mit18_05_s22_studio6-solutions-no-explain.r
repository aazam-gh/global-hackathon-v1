#---------------------------------------------------------
# File:   mit18_05_s22_studio6-solutions-no-explain.r 
# Authors: Jeremy Orloff and Jennifer French
#
# MIT OpenCourseWare: https://ocw.mit.edu
# 18.05 Introduction to Probability and Statistics
# Spring 2022
# For information about citing these materials or our Terms of Use, visit:
# https://ocw.mit.edu/terms.
#
#---------------------------------------------------------
# Studio 6 solutions with no explanations ----

# FRAGILE: This needs to be kept in sync with studio6-solutions. It is for use in the test-answers file. It replaces the cat statements used for explanations with a statement saying an explanation is needed.

# See its use in studio6-test-answers.Rmd

#--------------------------------------
# Problem 0: Averaging normal distributions.
# See instructions for this studio
studio6_problem_0 = function() { 
  cat("\n----------------------------------\n")
  cat("Problem 0: Averaging normal distributions \n")

  # This will draw the pair of histograms needed for this problem
  source('mit18_05_s22_studio6_problem0_draw_plot.r')
  studio6_problem0_draw_plot(10, 6, 9, 10000)

  # Do not change the above code.
  # ********* YOUR CODE HERE ***********

  cat('0. YOU NEED TO PUT YOUR COMPARISON OF THE HISTOGRAMS IN THE CAT STATEMENT.\n')
  #cat('0. Both histograms are centered near the true mean mu. The histogram of the averaged data is much narrower, i.e. less spread out from this mean.\n')
}

#---------------------------
# Problem 1: Cauchy distribution

# 1a. Formula for Cauchy pdf
studio6_problem_1a = function() {
  cat("\n----------------------------------\n")
  cat("Problem 1a. Formula for Cauchy pdf\n")


  # Do not change the above code.
  # ********* YOUR CODE HERE ***********

  cat("1a. YOU NEED TO PUT THE FORMULA f(x | theta) FOR THE CAUCHY DISTRIBUTION IN THE CAT STATEMENT.\n")
  # cat("1a. f(x | theta) = 1/(pi*(1+(x-theta)^2))\n")
}

# Problem 1c: Explain fat tails
studio6_problem_1c = function() {
  cat("-----\n")
  cat("1c. Explain fat tails\n")

  
  # Do not change the above code.
  # ********* YOUR CODE HERE ***********

  cat("1c. YOU NEED TO PUT YOUR EXPLANATION FOR FAT TAILS IN THE CAT STATEMENT.\n")
  # cat("1c. Answer: The tails are the left and right ends of the graph. In its tails the Cauchy graph is much higher than the normal, i.e. the tails of the Cauchy are much fatter than those of the normal.\n")
}

#--------------------------------------
# Problem 2: Cauchy's lighthouse ----

# Problem 2b:. Discretized Bayesian updates----
studio6_problem_2b = function(data_frame_csv) {
  cat("-----\n")
  cat("2b. Discretized Bayesian updates and MAP estimates.\n")

  # Arguments:
  #  data_frame_csv = name of the data file. (The grader will use a different data file than the test scripts.)

  # We give the unknown parameter theta a prior that follows a Uniform(theta_min, theta_max) distribution.
  # Use these values
  theta_min = -10
  theta_max = 10
  dtheta = 0.02 # Stepsize for discretizing the prior.

  # Load the data
  studio6_data_frame = read.csv(data_frame_csv)
  position_data = studio6_data_frame[,'position']

  # Do not change the above code.
  # ********* YOUR CODE FOR HERE***********

  # 2b(i)
  # Discretize the uniform(theta_min, theta_max) prior. (This is a distribution of theta).
  
  # The first array is 'unnormalized' because it doesn't sum to 1
  theta_range = seq(theta_min, theta_max, dtheta)
  unnormalized_uniform_prior = rep(1,length(theta_range))
  # To normalize we want sum(prior) = 1
  discrete_prior = unnormalized_uniform_prior/(sum(unnormalized_uniform_prior))

  ndata = length(position_data)
  cauchy_scale = 1.0  # This is given to us.

  # Initialize matrix whose jth column will store
  # the posterior distribution after the jth update
  # We will use this to make plots at the end
  posterior_mat = matrix(NA, nrow=length(theta_range), ncol=ndata)

  
  # 2b(ii) Update by looping over the data
  prior = discrete_prior
  for (j in 1:ndata) {
    x = position_data[j]
    likelihood = dcauchy(x, location=theta_range, scale=cauchy_scale)
    bayes_numerator = likelihood*prior
    posterior = bayes_numerator/(sum(bayes_numerator))
    posterior_mat[,j] = posterior

    # Make the posterior the next prior
    prior = posterior
  }

  
  # 2b(iii) Plot graphs
  
  # First we set some sizes so all the graphs fit on the plot.
  ymin = 0
  ymax = max(posterior_mat, discrete_prior)
  # Create an empty plot with the correct ranges
  plot_title = "2b(iii). Posteriors (and prior) (Cauchy location)"
  plot(c(theta_min,theta_max), c(ymin,ymax), type='n', xlab="theta", ylab="pdf", main = plot_title)

  # Plot the original prior in red
  lines(theta_range, discrete_prior, col='red')

  # Plot each of the posteriors in various colors
  for (j in 1:ndata) {
    #R lets you cycle through its list of colors by using col=j
    lines(theta_range, posterior_mat[,j], col=j)
  }

  
  # 2b(iv) Find the maximum in each of the posteriors
  MAP_estimates = rep(0, ndata)
  for (j in 1:ndata) {
    k = which.max(posterior_mat[,j])  # Index of maximum probability
    MAP_estimates[j] = theta_range[k] # Pick theta with that max. prob
  }

  # Plot the MAPEstimates
  plot_title = "2b(iv). MAP estimate vs. index"
  plot(MAP_estimates, type='p', col='blue', pch=19, xlab="index", main=plot_title)

  print(paste("2b(iv) Final map estimate: ", MAP_estimates[ndata]))


  # 2b(v)
  # Make a separate plot of the final posterior pdf and MAP estimate
  plot_title = paste("2b(v). Final posterior. MAP = ", MAP_estimates[ndata])
  plot(theta_range, posterior_mat[,ndata], type='l',col='orange', lwd=2, xlab='theta', ylab='posterior', main=plot_title)
  abline(v=MAP_estimates[ndata],col='blue',lty='dashed')

  # 2b(vi) Where to look
  cat("2b(vi). YOU NEED TO PUT YOUR CONCLUSION ON WHERE TO LOOK IN THE CAT STATEMENT.\n")
  # cat("2b(vi). The posterior has most of its probability for theta between -1 and 1. This is significantly less distance to cover than the initial -10 to 10. I would go to the MAP estimate of -0.16 and search near there. I would also keep collecting data and updating my posterior.\n")
}

# Problem 2c:. OPTIONAL Explanation ----
studio6_problem_2c = function() {
  cat("-----\n")
  cat("Problem 2c (OPTIONAL). Explanation\n")


  # Do not change the above code.
  # ********* YOUR CODE HERE***********

  cat("2c (OPTIONAL). YOU NEED TO PUT YOUR EXPLANATION IN THE CAT STATEMENT.\n")
}
