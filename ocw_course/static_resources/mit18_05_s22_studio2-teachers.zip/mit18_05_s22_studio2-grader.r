#---------------------------------------------------------
# File:   mit18_05_s22_studio2-grader.r 
# Authors: Jeremy Orloff and Jennifer French
#
# MIT OpenCourseWare: https://ocw.mit.edu
# 18.05 Introduction to Probability and Statistics
# Spring 2022
# For information about citing these materials or our Terms of Use, visit:
# https://ocw.mit.edu/terms.
#
#---------------------------------------------------------
# Grade studio 2
#-----------
# Expected output in studio2-grader.html
# If this file changes --need to rebuild studio*-grader.html

# Use 'File > Compile report...' to create an R Markdown report from this.
# Because this opens a new session, it doesn't see the environment.
# So we need the following line, which should be commented out when using the grading script for grading.

# source('mit18_05_s22_studio2-solutions.r')  ### COMMENT OUT FOR GRADING
# cat("WARNING: make sure source('mit18_05_s22_studio*-solutions.r') is commented out before grading\n")

#--------------
# For grading, open this file and set working directory to source file location

#--------------
studio2_problem_1a(12, 0.8, 6, 50000)
studio2_problem_1b(12, 0.8, 6)
studio2_problem_2a() 
studio2_problem_2b()
studio2_problem_2c(5000)
studio2_problem_3(8, 5000)
