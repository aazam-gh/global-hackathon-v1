#---------------------------------------------------------
# File:   mit18_05_s22_studio2-solutions-no-explain.r 
# Authors: Jeremy Orloff and Jennifer French
#
# MIT OpenCourseWare: https://ocw.mit.edu
# 18.05 Introduction to Probability and Statistics
# Spring 2022
# For information about citing these materials or our Terms of Use, visit:
# https://ocw.mit.edu/terms.
#
#---------------------------------------------------------
# studio2-solutions-no-explain.r
#
# For use in studio2-test-answers.Rmd to override certain print statements

studio2_problem_2b = function() {
  cat("-----\n")
  cat("2b. Exact computation.\n")

  # Arguments:
  #    None.

  phead = 0.6
  ntosses = 10
  exact_value = 0  # Should hold the exact value of what you computed.
  what_I_computed = "Redefine this below with your answer"
  bet_quality = "is or is not good bet" # redefine this below

  # Do not change the above code.
  # ********* YOUR CODE BELOW HERE ***********

  # These cat statements print out your answer
  cat('Parameters:', 'ntosses =', ntosses, ', phead =', phead, '\n')
  cat("I used R to compute", "[THIS SHOULD BE A DESCRIPTION OF WHAT YOU COMPUTED]", "\n")
  cat("The exact value is", "[THIS WILL BE THE VALUE OF WHAT YOU COMPUTED]", "\n")
  cat("This", "[PUT HERE: is a good bet OR is not a good bet].", "\n")
}

