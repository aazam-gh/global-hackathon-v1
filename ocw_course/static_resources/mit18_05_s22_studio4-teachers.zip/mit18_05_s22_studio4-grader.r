#---------------------------------------------------------
# File:   mit18_05_s22_studio4-grader.r 
# Authors: Jeremy Orloff and Jennifer French
#
# MIT OpenCourseWare: https://ocw.mit.edu
# 18.05 Introduction to Probability and Statistics
# Spring 2022
# For information about citing these materials or our Terms of Use, visit:
# https://ocw.mit.edu/terms.
#
#---------------------------------------------------------
# Studio 4 grader
#-----------
# Expected output in studio4-grader.html
# If this file changes --need to rebuild studio*-grader.html

# Use 'File > Compile report...' to create an R Markdown report from this.
# Because this opens a new session, it doesn't see the environment.
# So we need the following line, which should be commented out when using the grading script for grading.

# source('mit18_05_s22_studio4-solutions.r')  ### COMMENT OUT FOR GRADING
# cat("WARNING: make sure source('mit18_05_s22_studio*-solutions.r') is commented out before grading\n")

#--------------
# For grading, open this file and set working directory to source file location

#--------------
studio4_problem_1a(15, 24, 10000)
studio4_problem_1a(15, 100, 10000)
studio4_problem_1b()
studio4_problem_2(1600, 10000)
